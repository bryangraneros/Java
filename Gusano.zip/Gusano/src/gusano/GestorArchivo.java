package gusano;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class GestorArchivo {
	private String nombre;
	private List<ComputadoraInfectada> listComp;
	
	GestorArchivo(String n) {
		nombre = n;
	}
	
	@SuppressWarnings("finally")
	public RedComputadoras procesarArchivo() {
		Scanner arch = null;
		RedComputadoras redPc = null;
		
		try {
			arch = new Scanner(new File("src/Casos de prueba/" + nombre + ".in"));
			
			int cantAristas = arch.nextInt();
			
			Set<Integer> setNodos = new TreeSet<Integer>();
			List<Nodo> listaNodos = new LinkedList<Nodo>();
			
			for (int i = 0; i < cantAristas; i++) {
				int desde = arch.nextInt() -1;
				int val = arch.nextInt();
				int hasta = arch.nextInt() -1;
				
				setNodos.add(desde);
				setNodos.add(hasta);
								
				Nodo nodo = new Nodo(desde, val, hasta);
				listaNodos.add(nodo);	
			}

			Grafo grafo = new Grafo(setNodos.size());
			
			for(Nodo nodo : listaNodos) {
				grafo.agregarArista(nodo.getDesde(), nodo.getPeso(), nodo.getHasta());
			}
			
			int cantPcInfectadas = arch.nextInt();
			List<ComputadoraInfectada> listaPcInf  = new LinkedList<ComputadoraInfectada>();
			
			for (int i = 0; i < cantPcInfectadas; i++) {
				int pc = arch.nextInt() -1;
				int hora = arch.nextInt();
				ComputadoraInfectada pcInf = new ComputadoraInfectada(pc, hora);
				listaPcInf.add(pcInf);
			}
			
			redPc = new RedComputadoras(grafo, listaPcInf);
			
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if(arch != null) {
				arch.close();
			}
			return redPc;
		}
	}

	public void generarArchivoOut(Set<Integer> tset) {
		FileWriter arch = null;
		try {
			arch = new FileWriter("src/Casos de prueba/" + nombre + ".out");
			
			for (Integer integer : tset) {
				integer++;
				arch.write(integer + " ");
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(arch != null) {
				try {
					arch.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
}
