package gusano;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class RedComputadoras {
	private Grafo grafo;
	private List<ComputadoraInfectada> listaPcInf;
	private int [][] res;
	
	public int[][] getRes() {
		return res;
	}

	public RedComputadoras(Grafo grafo, List<ComputadoraInfectada> listaPcInf) {
		this.grafo = grafo;
		this.listaPcInf = listaPcInf;
		this.res = null;
	}
	
	public List<ComputadoraInfectada> getListaPcInf() {
		return listaPcInf;
	}

	public Set<Integer> buscarNodoOrigen() {
		res = grafo.floyd();
		
		System.out.println("FLOYD");
		for (int i = 0; i < res.length; i++) {
			for (int j = 0; j < res.length; j++) {
				if (res[i][j] == Integer.MAX_VALUE)
					System.out.print("∞ ");
				else
					System.out.printf("%02d ", res[i][j]);
			}
			System.out.println();
		}
		System.out.println();

		boolean [][] mat = new boolean [listaPcInf.size()][res.length];
		int cont = 0;
		Set<Integer> tset = new TreeSet<Integer>();
		
		for (ComputadoraInfectada pcInf : listaPcInf) {
			for (int j = 0; j < res.length; j++) {
				if (res[pcInf.getComp()][j] == pcInf.getTiempoInfeccion()) {
					mat[cont][j] = true;
					tset.add(j);
				}
			}
			cont++;
		}
		
		for (int i = 0; i < mat.length; i++) {
			for (Integer n : tset) {
				if(!mat[i][n]) {
					tset.remove(n);
				}
			}
		}
		
		System.out.println("Nodos origen gusano");
		for (Integer integer : tset) {
			System.out.println(integer + " ");
		}
		
		return tset;
	}
	
	public void imprimir() {
		System.out.println("Matriz adyacencia");
		grafo.imprimir();
		System.out.println("Pcs infectadas");
		for (ComputadoraInfectada computadoraInfectada : listaPcInf) {
			System.out.println(computadoraInfectada.getComp() + " " + computadoraInfectada.getTiempoInfeccion());
		}
		System.out.println();
		
	}
	
}
