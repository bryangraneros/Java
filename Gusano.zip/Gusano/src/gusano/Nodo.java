package gusano;

public class Nodo {
	private int desde;
	private int hasta;
	private int peso;
	
	public Nodo(int desde, int peso, int hasta) {
		this.desde = desde;
		this.hasta = hasta;
		this.peso = peso;
	}

	public int getDesde() {
		return desde;
	}

	public int getHasta() {
		return hasta;
	}

	public int getPeso() {
		return peso;
	}
	
	
}
