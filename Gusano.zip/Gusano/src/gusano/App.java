package gusano;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class App {
	public static void main(String[] args) {

		GestorArchivo arch = new GestorArchivo("caso1");
		RedComputadoras redPc = arch.procesarArchivo();
		redPc.imprimir();
		
		Set<Integer> tset = redPc.buscarNodoOrigen();
		arch.generarArchivoOut(tset);

	}
}
