package gusano;

import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;


public class TestRedComputadoras {

	@Test
	// CASO DEL PARCIAL|
	public void caso1() {
		GestorArchivo arch = new GestorArchivo("caso1");
		RedComputadoras redPc = arch.procesarArchivo();
		Set<Integer> tset = redPc.buscarNodoOrigen();

		int[][] res = redPc.getRes();
		List<ComputadoraInfectada> listPcInf = redPc.getListaPcInf();

		for (ComputadoraInfectada pcInf : listPcInf) {
			for (Integer nodo : tset) {
				Assert.assertEquals(res[pcInf.getComp()][nodo], pcInf.getTiempoInfeccion());
			}
		}

		arch.generarArchivoOut(tset);
	}
	
	@Test
	public void casoDosPosiblesPcOrigen() {
		GestorArchivo arch = new GestorArchivo("casoDosPosiblesPcOrigen");
		RedComputadoras redPc = arch.procesarArchivo();
		redPc.imprimir();
		
		Set<Integer> tset = redPc.buscarNodoOrigen();

		int[][] res = redPc.getRes();
		List<ComputadoraInfectada> listPcInf = redPc.getListaPcInf();

		for (ComputadoraInfectada pcInf : listPcInf) {
			for (Integer nodo : tset) {
				Assert.assertEquals(res[pcInf.getComp()][nodo], pcInf.getTiempoInfeccion());
			}
		}

		arch.generarArchivoOut(tset);
	}
}
