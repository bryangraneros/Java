package gusano;

public class ComputadoraInfectada {
	private int comp;
	private int tiempoInfeccion;
	
	public ComputadoraInfectada(int comp, int tiempoInfeccion) {
		this.comp = comp;
		this.tiempoInfeccion = tiempoInfeccion;
	}

	public int getComp() {
		return comp;
	}

	public int getTiempoInfeccion() {
		return tiempoInfeccion;
	}
	
}
